//
import UIKit
import WebKit

class FA: UIViewController, WKUIDelegate{
    
    @IBAction func But1(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.aucegypt.edu/admissions/financial-aid")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func But2(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://signup.aucegypt.edu/EmailProvisioning/Prospective/CreateProspective.aspx")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func But3(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.aucegypt.edu/admissions/financial-aid/faqs")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    var WEBY: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var myURl: URL!

}
