import UIKit
import WebKit

class DSGN: UIViewController, WKUIDelegate{
    
    
    @IBAction func b1(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://shibboleth-idp.collegenet.com/idp/profile/SAML2/Redirect/SSO?SAMLRequest=fZJBT8IwFMe%2FytI76zYRZsOWIBwkQSFsevBiuvKEJl07%2Bzon396xgcKFW9O%2B%2Fv7v%2FdoJ8lJVbFq7vd7AVw3ovJ9SaWTdQUJqq5nhKJFpXgIyJ1g2fV6yyA9YZY0zwijiTRHBOmn0zGisS7AZ2G8p4HWzTMjeuQoZpU3T%2BLyq1KGBwhempLiXRWEUuD3N%2FpY%2BoqHHiIiuV1lOvHnbk9T8SP9n%2FV8dyG3V0pSCHWhwHbjdom1zn1LBCbWBrbQgHM2yFfEW84R8QCyG97HgW%2FEgeMBjPo7jUVgEEAQghqJoyxBrWGh0XLuEREEUDYJwEI7zcMSGIbsL34m3Pjl4lHor9e62sKIvQvaU5%2BtBP94bWOxGawtIOjlqZ12wvXiI21h%2Btk%2FSs58Lz1dmuBCm1o5O6EVQn1qxl5a8mK%2BNkuLgTZUyzcwCd5CQkNC0v3L9V9Jf&RelayState=https%3A%2F%2Fwww.applyweb.com%2Fshibboleth%2Fgatekeeper%3Fdest%3D%252Fforms%252Faucg15%253F")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func b2(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.applyweb.com/auc/pdf/Instructions_Graduate_Application-Degree_Seeking_2021-2022.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    
    @IBAction func b3(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.applyweb.com/auc/pdf/Checklist_Graduate_Application-Degree_Seeking_2021-2022.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    var WEBY: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var myURl: URL!

}
