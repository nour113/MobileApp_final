package com.example.awra2y;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Home_Page extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_layout);

        Button aucButton = (Button) findViewById(R.id.aucButton);
        Button n_aucButton = (Button) findViewById(R.id.n_aucButton);

        aucButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent= new Intent(Home_Page.this, log_in.class);
                startActivity(intent);
                finish();
            }
        });
        n_aucButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent= new Intent(Home_Page.this, Non_AUCian_Student.class);
                startActivity(intent);
                finish();
            }
        });

        BottomNavigationView navView = findViewById(R.id.bottomNav_view);

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_home,
                R.id.navigation_mail, R.id.navigation_profile ).build();

        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                Intent intent;

                switch (item.getItemId())
                {
                    case R.id.navigation_home:
                        intent= new Intent(Home_Page.this, Home_Page.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_mail:
                        intent= new Intent(Home_Page.this, Mail_Activity.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_profile:
                        intent= new Intent(Home_Page.this, log_in.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                return true;
            }
        });
    }
}











