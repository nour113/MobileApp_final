//  EMVC.swift
//  Navigation
//
//  Created by Mostafa El Sharkawy on 20/01/2022.
//
import UIKit
import WebKit

class EMVC: UIViewController, WKUIDelegate{
    
    
    @IBAction func Button1(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://shibboleth-idp.collegenet.com/idp/profile/SAML2/Redirect/SSO?SAMLRequest=fZLLbsIwEEV%2FJfIeTAzhYZFIFBZFogWRtItuKscMYMmxU4%2FTtH%2Ff8CqwYWfZ43Nnjj1GUeiSTyq%2FN2v4qgB98FNog%2Fx4EJPKGW4FKuRGFIDcS55OXhactTu8dNZbaTUJJojgvLJmag1WBbgU3LeS8LZexGTvfYmc0rqu26Is9W8NeVvaguJe5bnV4Pc0%2FV%2B2ES09RDC6WqYZCWZNT8qIA%2F3Kul5tqU3Z0LSGHRjwR3CzRZvmtkrDGbWGjXIgPU3TJQnms5h8CgnDcJiPeh3Z7bH%2BKIxC1mVRHnUH2xHbRE0ZYgVzg14YHxPWYazVCVvhIAv7PGI8HHyQYHV28KTMRpndY2H5qQj5c5atWqfx3sHhcbSmgCTjg3Z%2BDHY3D%2FEYKy72SXLxc%2BP5zoyQ0lbG0zG9CTqllvy1Ic9nK6uV%2FA0mWtt66kB4iElIaHK6cv9Xkj8%3D&RelayState=https%3A%2F%2Fwww.applyweb.com%2Fshibboleth%2Fgatekeeper%3Fdest%3D%252Fforms%252Faucemba%253F")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
        
    }
    
    
    @IBAction func Button2(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.applyweb.com/auc/pdf/AUCEMBAemba_checklist_2022.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
        
    }
    var WEBY: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var myURl: URL!

}


