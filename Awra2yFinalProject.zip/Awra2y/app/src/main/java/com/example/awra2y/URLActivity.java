package com.example.awra2y;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import com.example.awra2y.model.UrlItem;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.net.URL;
import java.util.ArrayList;

public class URLActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.url_layout);

        String categoryTitle = "";

        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
            categoryTitle = bundle.getString("categoryTitle");

        TextView TV = (TextView) findViewById(R.id.categoryName);

        String C_Title = categoryTitle;
        if (categoryTitle.contains("|"))
            C_Title = categoryTitle.substring(categoryTitle.indexOf('|')+1,categoryTitle.length());

        if (C_Title.contains("/"))
            C_Title = C_Title.substring(0, C_Title.indexOf('/'));
        if (C_Title.contains("("))
            C_Title = C_Title.substring(0, C_Title.indexOf('('));

        TV.setText(C_Title);

        String catogeryTitles[]  = getResources().getStringArray(R.array.catogeryTitles);
        String AucUrl_Titles[]  = getResources().getStringArray(R.array.AucUrl_Titles);

        ArrayList<UrlItem> itemList = new ArrayList<>();

        for (int i=0; i<catogeryTitles.length; i++)
            if (categoryTitle.equals(catogeryTitles[i]))
            {
                String S[] = getResources().getStringArray(R.array.auc_url);
                UrlItem urlItem = new UrlItem(catogeryTitles[i], AucUrl_Titles[i], S[i]);
                itemList.add(urlItem);
            }

        URLAdapter M_Adaptor = new URLAdapter(this, itemList);

        ListView listview = findViewById(R.id.url_list);
        listview.setAdapter(M_Adaptor);

        listview.setClickable(true);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l)
            {
                String itemUrl = itemList.get(pos).auc_Url;
                String temp = itemUrl.substring(itemUrl.length()-4);

                if (temp.equals(".pdf"))
                    itemUrl = "https://docs.google.com/gview?embedded=true&url=" + itemUrl;

                Intent intent = new Intent(URLActivity.this, linkView_Activity.class);
                intent.putExtra("itemUrl", itemUrl);
                intent.putExtra("itemTitle", itemList.get(pos).title);
                startActivity(intent);
            }
        });
        BottomNavigationView navView = findViewById(R.id.bottomNav_view);

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_home,
                R.id.navigation_mail, R.id.navigation_profile).build();

        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                Intent intent;

                switch (item.getItemId())
                {
                    case R.id.navigation_home:
                        intent= new Intent(URLActivity.this, Home_Page.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_mail:
                        intent= new Intent(URLActivity.this, Mail_Activity.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_profile:
                        intent= new Intent(URLActivity.this, log_in.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                return true;
            }
        });
    }
}


