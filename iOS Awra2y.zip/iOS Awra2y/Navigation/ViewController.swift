//
//  ViewController.swift
//  Navigation
//
//  Created by auc on 19/01/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

