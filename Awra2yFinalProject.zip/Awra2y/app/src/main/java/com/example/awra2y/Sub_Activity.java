package com.example.awra2y;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.awra2y.model.Category;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;

public class Sub_Activity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub_layout);

        String categoryTitle = "";
        String isAucian = "";

        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
        {
            categoryTitle = bundle.getString("categoryTitle");
            isAucian = bundle.getString("isAucian");
        }

        TextView TV = (TextView) findViewById(R.id.title_categoryList);

        String C_Title = categoryTitle;
        if (categoryTitle.contains("/"))
            C_Title = categoryTitle.substring(0, categoryTitle.indexOf('/'));

        TV.setText(C_Title);

        ArrayList<Category> categoryList = new ArrayList<>();

        String Category_Degree[]  = getResources().getStringArray(R.array.sub_Non_Catogeries);

        if (isAucian.equals("true"))
        {
            Category_Degree = getResources().getStringArray(R.array.sub_Aucian_Catogeries);
            String Map_Category_Degree[]  = getResources().getStringArray(R.array.subMap_Aucian_Catogeries);

            for (int i=0; i<Category_Degree.length; i++)
                if (Map_Category_Degree[i].equals(categoryTitle))
                {
                    Category category = new Category(Category_Degree[i]);
                    categoryList.add(category);
                }
        }
        else
        {
            for (int i=0; i<Category_Degree.length; i++)
            {
                Category category = new Category(Category_Degree[i]);
                categoryList.add(category);
            }

        }
        CategoryAdapter C_Adaptor = new CategoryAdapter(this, categoryList);

        ListView listview = findViewById(R.id.category_list);
        listview.setAdapter(C_Adaptor);

        listview.setClickable(true);
        String finalCategoryTitle = categoryTitle;

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l)
            {
                Intent intent = new Intent(Sub_Activity.this, URLActivity.class);
                String temp = finalCategoryTitle + "|" + categoryList.get(pos).title;
                intent.putExtra("categoryTitle", temp);
                startActivity(intent);
            }
        });
        BottomNavigationView navView = findViewById(R.id.bottomNav_view);

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_home,
                R.id.navigation_mail, R.id.navigation_profile).build();

        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                Intent intent;

                switch (item.getItemId())
                {
                    case R.id.navigation_home:
                        intent= new Intent(Sub_Activity.this, Home_Page.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_mail:
                        intent= new Intent(Sub_Activity.this, Mail_Activity.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_profile:
                        intent= new Intent(Sub_Activity.this, log_in.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                return true;
            }
        });
    }
}
