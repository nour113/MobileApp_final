package com.example.awra2y;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PdfPrint;
import android.print.PrintAttributes;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.io.File;

public class linkView_Activity extends AppCompatActivity
{
    WebView webview;
    String url = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.linkview_layout);

        String itemUrl = "";
        String Title = "";
        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
        {
            itemUrl = bundle.getString("itemUrl");
            Title = bundle.getString("itemTitle");
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M)
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED)
            {
                Log.d("permission", "permission denied to WRITE_EXTERNAL_STORAGE - requesting it");
                String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissions, 1);
            }

        webview = findViewById(R.id.webview);
        webview.setWebViewClient(new WebViewClient());
        webview.getSettings().setSupportZoom(true);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setLoadsImagesAutomatically(true);
        webview.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        url = itemUrl;
        webview.loadUrl(itemUrl);

        Button button = (Button) findViewById(R.id.button);
        String finalTitle = Title;
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                createWebPrintJob(webview, finalTitle);
            }
        });

        if (!(itemUrl.endsWith(".pdf")))
        {
            button.setVisibility(View.GONE);
        }
        /*
        BottomNavigationView navView = findViewById(R.id.bottomNav_view);

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_home,
                R.id.navigation_mail, R.id.navigation_profile).build();

        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                Intent intent;

                switch (item.getItemId())
                {
                    case R.id.navigation_home:
                        intent= new Intent(linkView_Activity.this, Home_Page.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_mail:
                        intent= new Intent(linkView_Activity.this, Mail_Activity.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_profile:
                        intent= new Intent(linkView_Activity.this, log_in.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                return true;
            }
        });
        */
    }
    private void createWebPrintJob(WebView webView, String title)
    {
        String jobName = getString(R.string.app_name) + " Document";

        PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 600, 600))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();

        //File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/PDFTest/");
        File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        PdfPrint pdfPrint = new PdfPrint(attributes);

        pdfPrint.print(webView.createPrintDocumentAdapter(jobName), path, title+ ".pdf");

    }
}