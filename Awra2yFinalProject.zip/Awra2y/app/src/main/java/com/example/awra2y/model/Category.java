package com.example.awra2y.model;

public class Category
{
    public String title;
    public int imageId;

    public Category (String name, int id)
    {
        title = name;
        imageId = id;
    }
    public Category (String name)
    {
        title = name;
    }
}
