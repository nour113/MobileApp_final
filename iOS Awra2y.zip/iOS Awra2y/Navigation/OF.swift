import UIKit
import WebKit

class OF: UIViewController, WKUIDelegate{
    
    @IBAction func Bu1(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Auditor%20Registration%20form%20-%20Oct.%202017%20(final%20updates).pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    
    @IBAction func Bu2(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Docment%20Clearance.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu3(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Course%20Planning%20Form%20(Mar%2021%2C%202012).pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu4(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"http://forms.aucegypt.edu/registrar/repeatregform.htm")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func BU5(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"http://forms.aucegypt.edu/registrar/credentials.htm")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu6(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"http://www4.aucegypt.edu/declaration")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu7(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"http://www4.aucegypt.edu/declaration")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu8(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://registraronlineforms.aucegypt.edu/node/add/extension-of-study-period")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu9(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Dual%20Degree.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func BU10(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Independent%20Study.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu11(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu12(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Incomplete%20UG%20Form%20(May%2031%2C%202017).pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu13(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/docs/students_registrar_forms/Repeat%20Policy%20%28Grads%29.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func BU14(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Study%20Abroad%20Graduate%20Transfer%20Credit%20PreApproval%20Form.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func BU15(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Petition%20form%20Major%20field%20added%20(Mar%2018%2C%202020)%20(1).pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu16(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/Substitution%20Form-Updated%20April%2021%2C%202021.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu17(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/Docs/students_Registrar/6141_SSC%20withdrawal-form-March2020.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    
    
    var WEBY: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var myURl: URL!

}
