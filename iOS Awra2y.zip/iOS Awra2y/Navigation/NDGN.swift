import UIKit
import WebKit

class NDGN: UIViewController, WKUIDelegate{
    
    @IBAction func b1(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://shibboleth-idp.collegenet.com/idp/profile/SAML2/Redirect/SSO?SAMLRequest=fZLLbsIwEEV%2FJfI%2BMUmgAYsgUVgUiZaI0C66qRwzgCXHTj1OU%2F6%2B4VVgw86yx%2BfOHHuIvFQVG9dup5fwXQM677dUGtnxICW11cxwlMg0LwGZEywfv85ZFHRYZY0zwijijRHBOmn0xGisS7A52B8p4H05T8nOuQoZpU3TBLyq1L6BIhCmpLiTRWEUuB3N%2F5cBoqGHiIhmi3xFvGnbk9T8QL%2Byrld9ua5amlKwBQ3uCG63aNvcRio4o5awlhaEo3m%2BIN5smpKvuAuDPmwSsRG9JA5jEW%2B6IuoVkAz6YcjjtgyxhplGx7VLSdSJIr8T%2BmGyCp9YN2K9%2BJN42dnBs9RrqbePhRWnImQvq1Xmn8b7AIvH0doCMhoetLNjsL15iMdYfrFPRhc%2FN57vzHAhTK0dHdKboFNqxd5a8myaGSXF3hsrZZqJBe4gJSGho9OV%2B78y%2BgM%3D&RelayState=https%3A%2F%2Fwww.applyweb.com%2Fshibboleth%2Fgatekeeper%3Fdest%3D%252Fforms%252Faucgnd%253F")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    
    @IBAction func b2(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.applyweb.com/auc/pdf/Instructions_Graduate_Application-Non_Degree_2021-2022.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    
    @IBAction func b3(_ sender: Any) {
        
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.applyweb.com/auc/pdf/Checklist_Graduate_Application-Non_Degree_2021-2022.pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    var WEBY: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var myURl: URL!

}
