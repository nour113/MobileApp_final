package com.example.awra2y;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import android.view.LayoutInflater;
import android.widget.TextView;
import com.example.awra2y.model.UrlItem;

public class URLAdapter extends ArrayAdapter<UrlItem>
{
    public URLAdapter(Context context, ArrayList <UrlItem> urlList)
    {
        super(context, R.layout.url_itemlist, urlList);
    }

    @NonNull @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        UrlItem item = getItem(position);

        if (convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.url_itemlist, parent, false);

        TextView TV = convertView.findViewById(R.id.urlTitile);

        String C_Title = item.title;
        if (item.title.contains("|"))
            C_Title = item.title.split("|")[1];

        TV.setText("- "+ C_Title);

        return convertView;
    }
}
