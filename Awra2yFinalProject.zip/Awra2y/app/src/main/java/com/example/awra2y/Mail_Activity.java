package com.example.awra2y;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.awra2y.model.UrlItem;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;

public class Mail_Activity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mail_layout);

        String mailTitles[]  = getResources().getStringArray(R.array.mailTitles);
        String url_mails[]  = getResources().getStringArray(R.array.url_mails);

        ArrayList<UrlItem> itemList = new ArrayList<>();

        for (int i=0; i<mailTitles.length; i++)
        {
            UrlItem urlItem = new UrlItem(mailTitles[i], url_mails[i]);
            itemList.add(urlItem);
        }

        mailAdapter M_Adaptor = new mailAdapter(this, itemList);

        ListView listview = findViewById(R.id.mail_list);
        listview.setAdapter(M_Adaptor);

        listview.setClickable(true);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l)
            {
                String mail = itemList.get(pos).auc_Url;

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(android.content.Intent.EXTRA_EMAIL,new String[] { mail });
                startActivity(Intent.createChooser(intent, "Send Email"));
            }
        });
        BottomNavigationView navView = findViewById(R.id.bottomNav_view);

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_home,
                R.id.navigation_mail, R.id.navigation_profile).build();

        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                Intent intent;

                switch (item.getItemId())
                {
                    case R.id.navigation_home:
                        intent= new Intent(Mail_Activity.this, Home_Page.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_mail:
                        intent= new Intent(Mail_Activity.this, Mail_Activity.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_profile:
                        intent= new Intent(Mail_Activity.this, log_in.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                return true;
            }
        });

    }
}