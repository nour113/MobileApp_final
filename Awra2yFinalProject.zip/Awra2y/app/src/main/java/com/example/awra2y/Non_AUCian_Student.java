package com.example.awra2y;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.awra2y.model.Category;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;

public class Non_AUCian_Student extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auc_layout);

        String Category_Degree[]  = getResources().getStringArray(R.array.Category_Degree_NonAucian);
        String isSub_Category[]  = getResources().getStringArray(R.array.isSub_Category);

        ArrayList<Category> categoryList = new ArrayList<>();

        for (int i=0; i<Category_Degree.length; i++)
        {
            Category category = new Category(Category_Degree[i]);
            categoryList.add(category);
        }
        TextView TV = (TextView) findViewById(R.id.title_categoryList);
        TV.setText("Non AUCian Students");

        CategoryAdapter C_Adaptor = new CategoryAdapter(this, categoryList);

        ListView listview = findViewById(R.id.category_list);
        listview.setAdapter(C_Adaptor);

        listview.setClickable(true);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l)
            {
                if (isSub_Category[pos].equals("true"))
                {
                    Intent intent = new Intent(Non_AUCian_Student.this, Sub_Activity.class);
                    intent.putExtra("categoryTitle", categoryList.get(pos).title);
                    intent.putExtra("isAucian", "false");
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(Non_AUCian_Student.this, URLActivity.class);
                    intent.putExtra("categoryTitle", categoryList.get(pos).title);
                    startActivity(intent);
                }
            }
        });
        BottomNavigationView navView = findViewById(R.id.bottomNav_view);

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_home,
                R.id.navigation_mail, R.id.navigation_profile).build();

        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                Intent intent;

                switch (item.getItemId())
                {
                    case R.id.navigation_home:
                        intent= new Intent(Non_AUCian_Student.this, Home_Page.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_mail:
                        intent= new Intent(Non_AUCian_Student.this, Mail_Activity.class);
                        startActivity(intent);
                        finish();
                        break;
                    case R.id.navigation_profile:
                        intent= new Intent(Non_AUCian_Student.this, log_in.class);
                        startActivity(intent);
                        finish();
                        break;
                }
                return true;
            }
        });
    }

}



