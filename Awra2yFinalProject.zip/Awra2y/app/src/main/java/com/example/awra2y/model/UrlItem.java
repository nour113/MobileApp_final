package com.example.awra2y.model;

public class UrlItem
{
    public String catogery;
    public String title;
    public String auc_Url;

    public UrlItem (String cate, String name, String url)
    {
        title = name;
        catogery = cate;
        auc_Url = url;
    }
    public UrlItem (String name, String url)
    {
        title = name;
        auc_Url = url;
    }
}
