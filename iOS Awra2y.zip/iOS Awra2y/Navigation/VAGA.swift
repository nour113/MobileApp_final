import UIKit
import WebKit

class VAGA: UIViewController, WKUIDelegate{
    
    @IBAction func Bu1(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www.aucegypt.edu/students/registrar/military-and-visa#visa")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func Bu2(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://documents.aucegypt.edu/docs/students_Registrar_forms/Student%20Visa%20Enrollment%20Certificate%20Request%20(Aug%202015).pdf")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    var WEBY: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var myURl: URL!

}
