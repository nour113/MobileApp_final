package com.example.awra2y;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import android.view.LayoutInflater;
import android.widget.TextView;
import com.example.awra2y.model.UrlItem;

public class mailAdapter extends ArrayAdapter<UrlItem>
{
    public mailAdapter(Context context, ArrayList <UrlItem> mail_list)
    {
        super(context, R.layout.mail_itemlist, mail_list);
    }

    @NonNull @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        UrlItem item = getItem(position);

        if (convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.mail_itemlist, parent, false);

        TextView TV = convertView.findViewById(R.id.urlTitile);
        TextView TV2 = convertView.findViewById(R.id.mail);

        TV.setText(item.title);
        TV2.setText(item.auc_Url);

        return convertView;
    }
}
