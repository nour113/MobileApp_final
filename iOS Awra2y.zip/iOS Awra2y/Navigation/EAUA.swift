import UIKit
import WebKit

class EAUA: UIViewController, WKUIDelegate{
    
    @IBAction func Bu1(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www4.aucegypt.edu/registrarepay/")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    @IBAction func bu2(_ sender: Any) {
        let constraints = [
            view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            view.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            view.widthAnchor.constraint(equalToConstant: 100),
            view.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor)
        ]
        myURl = URL(string:"https://www4.aucegypt.edu/registrarepay/")
        let webConfiguration = WKWebViewConfiguration()
        WEBY = WKWebView(frame: .zero, configuration: webConfiguration)
        WEBY.uiDelegate = self
        view =  WEBY
        NSLayoutConstraint.activate(constraints)
        let myRequest = URLRequest(url: myURl)
        WEBY.load(myRequest)
    }
    var WEBY: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var myURl: URL!

}
